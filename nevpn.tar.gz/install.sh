#!/bin/bash

# مسیر فولدری که اسکریپت در اون قرار داره (مسیر اکسترکت شده)
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# مسیر فایل دسکتاپ در دسکتاپ کاربر
DESKTOP_FILE="$HOME/Desktop/PurWin.desktop"

# ساخت فایل دسکتاپ
cat > "$DESKTOP_FILE" <<EOL
[Desktop Entry]
Type=Application
Name=PurWin
Exec=sudo python3 "$DIR/main.py"
Icon=$DIR/icon.png
Path=$DIR
Terminal=true
EOL

# قابل اجرا کردن فایل شورتکات
chmod +x "$DESKTOP_FILE"

echo "✅ شورتکات ساخته شد: $DESKTOP_FILE"
