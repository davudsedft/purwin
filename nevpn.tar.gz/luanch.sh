#!/bin/bash
# رفتن به مسیر خود فایل
cd "$(dirname "$0")"
# اجرای برنامه
python3 main.py
